# ScamShield - Holiday Scam Detector

## Setup Instructions

### Prerequisites

1.  **XAMPP** (or any LAMP/WAMP stack) with PHP and MySQL support.
2.  **Web Browser**.

### Installation

1.  **Start XAMPP**: Open the XAMPP Control Panel and start **Apache** and **MySQL**.
2.  **Database Setup**:
    - Open phpMyAdmin (usually at `http://localhost/phpmyadmin`).
    - Create a new database named `scamshield`.
    - Import the `database/setup.sql` file located in this project folder into the `scamshield` database.
3.  **Project Location**:
    - Ensure the project folder `ScamShield` is located in your `htdocs` directory (e.g., `C:\xampp\htdocs\ScamShield`).
4.  **Configuration**:
    - If you changed your MySQL root password from the default (empty), update `includes/db.php`.

### Running the Application

1.  Open your browser.
2.  Navigate to `http://localhost/ScamShield/index.php`.
3.  You should see the Home page with the Christmas theme and Snowfall effect.

### Features to Test

- **Scam Scanner**: Paste a suspicious text (e.g., "Win a free iPhone") and click Scan.
- **Education Hub**: Browse the tips.
- **Quiz**: Take the quiz and see your score.
- **Authentication**: Register a user and log in to see your scan history in the Dashboard.
