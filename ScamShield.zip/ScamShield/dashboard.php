<?php
require_once 'includes/db.php';
require_once 'includes/functions.php';
include 'includes/header.php';

if (!isLoggedIn()) redirect('login.php');

$user_id = $_SESSION['user_id'];

// Fetch User Stats
try {
    $scan_stmt = $pdo->prepare("SELECT * FROM scans WHERE user_id = ? ORDER BY scan_date DESC LIMIT 10");
    $scan_stmt->execute([$user_id]);
    $scans = $scan_stmt->fetchAll();

    $quiz_stmt = $pdo->prepare("SELECT * FROM quiz_results WHERE user_id = ? ORDER BY attempt_date DESC LIMIT 10");
    $quiz_stmt->execute([$user_id]);
    $quiz_results = $quiz_stmt->fetchAll();
} catch (PDOException $e) {
    $scans = [];
    $quiz_results = [];
}
?>

<div class="container">
    <h1>Welcome, <?php echo htmlspecialchars($_SESSION['user_name']); ?>! 🎅</h1>

    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
        <!-- Recent Scans -->
        <div>
            <h2><i class="fas fa-search"></i> Recent Scans</h2>
            <?php if (count($scans) > 0): ?>
                <div class="card">
                    <table>
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Input (Snippet)</th>
                                <th>Risk</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($scans as $scan): ?>
                                <tr>
                                    <td><?php echo date('M d, H:i', strtotime($scan['scan_date'])); ?></td>
                                    <td><?php echo htmlspecialchars(substr($scan['input_text'], 0, 30)) . '...'; ?></td>
                                    <td>
                                        <?php
                                        $class = $scan['risk_level'] == 'High' ? 'risk-high' : ($scan['risk_level'] == 'Moderate' ? 'risk-moderate' : 'risk-safe');
                                        echo "<span class='$class'>{$scan['risk_level']}</span>";
                                        ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <p>No scans yet.</p>
            <?php endif; ?>
        </div>

        <!-- Quiz Results -->
        <div>
            <h2><i class="fas fa-star"></i> Quiz History</h2>
            <?php if (count($quiz_results) > 0): ?>
                <div class="card">
                    <table>
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Score</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($quiz_results as $quiz): ?>
                                <tr>
                                    <td><?php echo date('M d, H:i', strtotime($quiz['attempt_date'])); ?></td>
                                    <td><?php echo "{$quiz['score']} / {$quiz['total_questions']}"; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <p>No quiz attempts yet.</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>