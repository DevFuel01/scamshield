<?php include 'includes/header.php'; ?>

<h1 style="text-align: center;"><i class="fas fa-question-circle"></i> Christmas Scam Quiz</h1>

<div class="card" id="quiz-container" style="max-width: 800px; margin: 0 auto;">
    <div id="loading" style="text-align: center;">
        <i class="fas fa-spinner fa-spin fa-2x"></i><br>Loading questions...
    </div>
    <form id="quiz-form" style="display: none;">
        <div id="questions-area"></div>
        <button type="submit" class="btn" style="margin-top: 20px; width: 100%;">Submit Answers</button>
    </form>
    <div id="quiz-results" style="display: none; text-align: center;">
        <h2>Quiz Completed!</h2>
        <p style="font-size: 1.5rem;">Score: <span id="score-display"></span></p>
        <div id="feedback-area" style="text-align: left; margin-top: 20px;"></div>
        <button class="btn" onclick="location.reload()" style="margin-top: 20px;">Try Again</button>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', () => {
        fetchQuestions();
    });

    let loadedQuestions = [];

    function fetchQuestions() {
        fetch('api/quiz_process.php')
            .then(res => res.json())
            .then(response => {
                if (response.status === 'success') {
                    loadedQuestions = response.data;
                    renderQuestions(response.data);
                } else {
                    document.getElementById('loading').innerHTML = 'Error loading quiz.';
                }
            })
            .catch(err => {
                console.error(err);
                document.getElementById('loading').innerHTML = 'Error loading quiz.';
            });
    }

    function renderQuestions(questions) {
        const container = document.getElementById('questions-area');
        container.innerHTML = '';

        questions.forEach((q, index) => {
            const qDiv = document.createElement('div');
            qDiv.className = 'form-group question-block';
            qDiv.style.marginBottom = '30px';
            qDiv.innerHTML = `
            <p><strong>${index + 1}. ${q.question}</strong></p>
            <label style="display:block; margin: 5px 0;"><input type="radio" name="q_${q.id}" value="A" required> ${q.option_a}</label>
            <label style="display:block; margin: 5px 0;"><input type="radio" name="q_${q.id}" value="B"> ${q.option_b}</label>
            <label style="display:block; margin: 5px 0;"><input type="radio" name="q_${q.id}" value="C"> ${q.option_c}</label>
            <label style="display:block; margin: 5px 0;"><input type="radio" name="q_${q.id}" value="D"> ${q.option_d}</label>
        `;
            container.appendChild(qDiv);
        });

        document.getElementById('loading').style.display = 'none';
        document.getElementById('quiz-form').style.display = 'block';
    }

    document.getElementById('quiz-form').addEventListener('submit', function(e) {
        e.preventDefault();

        const formData = new FormData(this);
        const answers = {};

        loadedQuestions.forEach(q => {
            answers[q.id] = formData.get(`q_${q.id}`);
        });

        fetch('api/quiz_process.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    answers: answers
                })
            })
            .then(res => res.json())
            .then(data => {
                if (data.status === 'success') {
                    document.getElementById('quiz-form').style.display = 'none';
                    document.getElementById('quiz-results').style.display = 'block';
                    document.getElementById('quiz-results').style.display = 'block';

                    let scoreHtml = `${data.score} / ${data.total}`;
                    if (data.score === data.total) {
                        scoreHtml += ' <br><span style="color:var(--christmas-green); font-size: 1.2em;">🎅 Ho Ho Ho! Perfect Score! 🎄</span>';
                    } else if (data.score >= data.total / 2) {
                        scoreHtml += ' <span style="color:var(--christmas-gold);">Good Job! 🎁</span>';
                    }

                    document.getElementById('score-display').innerHTML = scoreHtml;

                    // Detailed Feedback
                    const feedbackArea = document.getElementById('feedback-area');
                    let feedbackHtml = '<h3>Review Key:</h3><div style="margin-bottom: 15px;"><span style="color:var(--christmas-green);font-weight:bold;">✔ Correct</span> | <span style="color:var(--christmas-red);font-weight:bold;">✘ Incorrect</span></div>';

                    loadedQuestions.forEach((q, index) => {
                        const result = data.details[q.id];
                        const isCorrect = result.correct;
                        const userAns = result.user_answer || 'None';
                        const color = isCorrect ? 'var(--christmas-green)' : 'var(--christmas-red)';
                        const icon = isCorrect ? '✔' : '✘';

                        // Map option letter to text for clarity
                        const getOptionText = (opt) => {
                            if (opt === 'A') return q.option_a;
                            if (opt === 'B') return q.option_b;
                            if (opt === 'C') return q.option_c;
                            if (opt === 'D') return q.option_d;
                            return 'Unknown';
                        };

                        feedbackHtml += `<div class="card" style="border-left: 5px solid ${color}; padding: 10px;">`;
                        feedbackHtml += `<p><strong>${index + 1}. ${q.question}</strong></p>`;
                        feedbackHtml += `<p>Your Answer: <span style="font-weight:bold; color:${color}">${icon} ${getOptionText(userAns)}</span></p>`;

                        if (!isCorrect) {
                            feedbackHtml += `<p style="background:#fff3cd; padding:5px; border-radius:4px;"><strong>Correct Answer:</strong> ${getOptionText(result.correct_answer)}</p>`;
                        }
                        feedbackHtml += `</div>`;
                    });

                    feedbackArea.innerHTML = feedbackHtml;
                } else {
                    alert('Error submitting quiz.');
                }
            });
    });
</script>

<?php include 'includes/footer.php'; ?>