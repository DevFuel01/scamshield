<?php include 'includes/header.php'; ?>

<div class="hero" style="text-align: center; padding: 40px 20px;">
    <h1><i class="fas fa-sleigh"></i> Check Your Holiday Message 🎄</h1>
    <p style="font-size: 1.2rem;">Don't let scammers steal your Christmas joy. Paste a message or link below to scan for risks.</p>
</div>

<div class="card" style="max-width: 800px; margin: 0 auto;">
    <div class="form-group">
        <h2 style="font-size: 1.2rem; color: var(--christmas-red); margin-top: 0;"><i class="fas fa-gift"></i> Report Suspicious Link 🎁</h2>
        <label for="scan-input" style="font-weight: bold; display: block; margin-bottom: 10px;">Paste text, email content, or link here:</label>
        <textarea id="scan-input" class="form-control" rows="5" placeholder="e.g. 'Congratulations! You won a $1000 Walmart Gift Card! Click here to claim...'"></textarea>
    </div>
    <button class="btn" onclick="scanText()">Scan Now <i class="fas fa-search"></i></button>
</div>

<div id="result-area" class="card" style="max-width: 800px; margin: 20px auto; display: none;">
    <h2 id="result-title">Scan Result</h2>
    <p><strong>Risk Level:</strong> <span id="risk-level"></span></p>
    <div id="risk-details"></div>
</div>

<script>
    function scanText() {
        const text = document.getElementById('scan-input').value;
        if (!text.trim()) {
            alert('Please enter some text to scan.');
            return;
        }

        const btn = document.querySelector('button[onclick="scanText()"]');
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Scanning...';
        btn.disabled = true;

        fetch('api/scan_process.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    text: text
                })
            })
            .then(response => response.json())
            .then(data => {
                btn.innerHTML = 'Scan Now <i class="fas fa-search"></i>';
                btn.disabled = false;

                document.getElementById('result-area').style.display = 'block';

                const riskSpan = document.getElementById('risk-level');
                let iconHtml = '';

                if (data.risk === 'High') {
                    riskSpan.className = 'risk-high';
                    iconHtml = ' <i class="fas fa-exclamation-triangle"></i> (Watch out!)';
                } else if (data.risk === 'Moderate') {
                    riskSpan.className = 'risk-moderate';
                    iconHtml = ' <i class="fas fa-bell"></i> (Be Careful)';
                } else {
                    riskSpan.className = 'risk-safe';
                    iconHtml = ' <i class="fas fa-gift"></i> (Looks Safe)';
                }

                riskSpan.innerHTML = data.risk + iconHtml;

                const detailsDiv = document.getElementById('risk-details');

                // Highlighted Text Analysis
                let analyzedText = text;
                // sort matches by length desc to avoid partial replacement issues (e.g. 'bank account' vs 'bank')
                if (data.matches && data.matches.length > 0) {
                    data.matches.sort((a, b) => b.keyword.length - a.keyword.length);

                    data.matches.forEach(match => {
                        const regex = new RegExp(`(${match.keyword})`, 'gi');
                        analyzedText = analyzedText.replace(regex, `<span class="highlight-${match.risk}" title="${match.tip}">$1</span>`);
                    });
                }

                let detailsHtml = '<div style="background: #f9f9f9; padding: 15px; border-radius: 5px; margin: 15px 0;">';
                detailsHtml += '<h3><i class="fas fa-highlighter"></i> Analysis:</h3>';
                detailsHtml += `<p style="white-space: pre-wrap;">${analyzedText}</p>`;
                detailsHtml += '</div>';

                if (data.flags && data.flags.length > 0) {
                    detailsHtml += '<h4>Key Observations:</h4><ul>';
                    data.flags.forEach(flag => {
                        detailsHtml += `<li>${flag}</li>`;
                    });
                    detailsHtml += '</ul>';
                } else {
                    detailsHtml += '<p>No specific threats found. Always stay vigilant!</p>';
                }

                detailsDiv.innerHTML = detailsHtml;
            })
            .catch(err => {
                console.error(err);
                btn.innerHTML = 'Scan Now <i class="fas fa-search"></i>';
                btn.disabled = false;
                alert('An error occurred. Please try again.');
            });
    }
</script>

<?php include 'includes/footer.php'; ?>