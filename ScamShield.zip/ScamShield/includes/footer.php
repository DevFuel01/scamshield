    </main>
    <footer>
        <div class="container">
            <p>&copy; <?php echo date('Y'); ?> ScamShield. Stay Safe this Holiday Season! 🎄</p>
        </div>
    </footer>
    <script src="assets/js/script.js"></script>
    </body>

    </html>