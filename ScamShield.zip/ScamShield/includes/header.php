<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ScamShield - Holiday Scam Detector</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>

<body>
    <header>
        <div class="container navbar">
            <a href="index.php" class="logo">
                <i class="fas fa-shield-alt"></i> ScamShield
            </a>
            <button id="hamburger" class="hamburger" aria-label="Toggle navigation">
                <i class="fas fa-bars"></i>
            </button>
            <ul class="nav-links">
                <li><a href="index.php">Scam Checker</a></li>
                <li><a href="education.php">Education Hub</a></li>
                <li><a href="quiz.php">Quiz</a></li>
                <?php if (isset($_SESSION['user_id'])): ?>
                    <li><a href="dashboard.php">Stats</a></li>
                    <li><a href="#" onclick="logout()">Logout</a></li>
                <?php else: ?>
                    <li><a href="login.php">Login</a></li>
                <?php endif; ?>
                <li><button id="theme-toggle" class="btn-secondary" style="padding: 5px 10px; border-radius: 5px; margin-right: 5px;"><i class="fas fa-moon"></i></button></li>
                <li><button id="music-toggle" class="btn-secondary" style="padding: 5px 10px; border-radius: 5px;"><i class="fas fa-music"></i></button></li>
            </ul>
        </div>
    </header>
    <audio id="bg-music" loop>
        <source src="assets/audio/jingle.mp3" type="audio/mpeg">
    </audio>
    <main class="container">
        <script>
            function logout() {
                fetch('api/auth_process.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded'
                        },
                        body: 'action=logout'
                    })
                    .then(res => res.json())
                    .then(data => {
                        if (data.status === 'success') {
                            window.location.href = 'index.php';
                        }
                    });
            }
        </script>