/* Existing JavaScript */
document.addEventListener('DOMContentLoaded', () => {
    // Snowfall
    if(typeof createSnowflakes === 'function') createSnowflakes();
    
    // Quiz fetch if on quiz page
    if(document.getElementById('quiz-container')) {
        fetchQuestions();
    }
    
    // Theme Toggle
    const themeBtn = document.getElementById('theme-toggle');
    if(themeBtn) {
        // Load saved theme
        if(localStorage.getItem('theme') === 'dark') {
            document.body.classList.add('dark-mode');
            themeBtn.innerHTML = '<i class="fas fa-sun"></i>';
        }

        themeBtn.addEventListener('click', () => {
            document.body.classList.toggle('dark-mode');
            
            if(document.body.classList.contains('dark-mode')) {
                localStorage.setItem('theme', 'dark');
                themeBtn.innerHTML = '<i class="fas fa-sun"></i>';
            } else {
                localStorage.setItem('theme', 'light');
                themeBtn.innerHTML = '<i class="fas fa-moon"></i>';
            }
        });
    }

    // Hamburger Menu Toggle
    const hamburger = document.getElementById('hamburger');
    const navLinks = document.querySelector('.nav-links');
    
    if(hamburger && navLinks) {
        hamburger.addEventListener('click', () => {
            navLinks.classList.toggle('nav-active');
            // Change icon between bars and times (X)
            const icon = hamburger.querySelector('i');
            if (navLinks.classList.contains('nav-active')) {
                icon.classList.replace('fa-bars', 'fa-times');
            } else {
                icon.classList.replace('fa-times', 'fa-bars');
            }
        });
        
        // Close menu when clicking a link
        navLinks.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                navLinks.classList.remove('nav-active');
                hamburger.querySelector('i').classList.replace('fa-times', 'fa-bars');
            });
        });
    }

    // Music Toggle
    const musicBtn = document.getElementById('music-toggle');
    const bgMusic = document.getElementById('bg-music');
    
    if(musicBtn && bgMusic) {
        // Initialize state (default to off to avoid auto-play policy issues)
        bgMusic.volume = 0.3; // Low volume
        
        musicBtn.addEventListener('click', () => {
            if (bgMusic.paused) {
                bgMusic.play().then(() => {
                    musicBtn.innerHTML = '<i class="fas fa-pause"></i>';
                    musicBtn.classList.add('playing');
                }).catch(err => {
                    console.log("Audio play failed: ", err);
                    alert("Please interact with the document first or ensure 'assets/audio/jingle.mp3' exists.");
                });
            } else {
                bgMusic.pause();
                musicBtn.innerHTML = '<i class="fas fa-music"></i>';
                musicBtn.classList.remove('playing');
            }
        });
    }
});

function createSnowflakes() {
    const snowContainer = document.createElement('div');
    snowContainer.id = 'snow-container';
    document.body.appendChild(snowContainer);

    const numberOfSnowflakes = 50;
    const snowflakes = ['❄', '❅', '❆'];

    for (let i = 0; i < numberOfSnowflakes; i++) {
        const snowflake = document.createElement('div');
        snowflake.classList.add('snowflake');
        snowflake.innerText = snowflakes[Math.floor(Math.random() * snowflakes.length)];
        
        snowflake.style.left = Math.random() * 100 + 'vw';
        snowflake.style.animationDuration = Math.random() * 3 + 2 + 's';
        snowflake.style.opacity = Math.random();
        snowflake.style.fontSize = Math.random() * 10 + 10 + 'px';
        
        if (!document.getElementById('snow-keyframes')) {
            const style = document.createElement('style');
            style.id = 'snow-keyframes';
            style.innerHTML = `
                @keyframes fall {
                    0% { transform: translateY(-10vh) rotate(0deg); }
                    100% { transform: translateY(110vh) rotate(360deg); }
                }
            `;
            document.head.appendChild(style);
        }
        
        snowflake.style.animationName = 'fall';
        snowflake.style.animationTimingFunction = 'linear';
        snowflake.style.animationIterationCount = 'infinite';
        
        snowContainer.appendChild(snowflake);
    }
}

// Helper to show alerts
function showAlert(message, type = 'info') {
    alert(message);
}
