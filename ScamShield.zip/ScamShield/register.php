<?php include 'includes/header.php'; ?>
<?php if (isset($_SESSION['user_id'])) redirect('dashboard.php'); ?>

<div style="max-width: 400px; margin: 40px auto;">
    <div class="card">
        <h2 style="text-align: center; color: var(--christmas-green);">Register</h2>
        <form id="register-form">
            <div class="form-group">
                <label>Name</label>
                <input type="text" name="name" class="form-control" required>
            </div>
            <div class="form-group">
                <label>Email</label>
                <input type="email" name="email" class="form-control" required>
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" class="form-control" required>
            </div>
            <button type="submit" class="btn" style="width: 100%;">Create Account</button>
            <p style="text-align: center; margin-top: 15px;">
                Already have an account? <a href="login.php">Login here</a>
            </p>
        </form>
    </div>
</div>

<script>
    document.getElementById('register-form').addEventListener('submit', function(e) {
        e.preventDefault();
        const formData = new FormData(this);
        formData.append('action', 'register');

        fetch('api/auth_process.php', {
                method: 'POST',
                body: formData
            })
            .then(res => res.json())
            .then(data => {
                if (data.status === 'success') {
                    alert('Account created! You are now logged in.');
                    window.location.href = 'dashboard.php';
                } else {
                    alert(data.message);
                }
            })
            .catch(err => console.error(err));
    });
</script>

<?php include 'includes/footer.php'; ?>