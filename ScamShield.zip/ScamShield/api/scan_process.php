<?php

require_once '../includes/db.php';
require_once '../includes/functions.php';

$input = json_decode(file_get_contents('php://input'), true);
$text = $input['text'] ?? '';
$user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;

if (empty($text)) {
    jsonResponse(['risk' => 'Unknown', 'message' => 'Please enter text to scan.'], 400);
}

// Keyword Database with Risk and Tips
$scam_indicators = [
    ['word' => 'bank account', 'risk' => 'High', 'tip' => 'Never share bank details over message.'],
    ['word' => 'credit card', 'risk' => 'High', 'tip' => 'Legitimate requests for credit cards are rare in messages.'],
    ['word' => 'password', 'risk' => 'High', 'tip' => 'Never share your password with anyone.'],
    ['word' => 'urgent', 'risk' => 'High', 'tip' => 'Scammers use urgency to stop you from thinking.'],
    ['word' => 'act now', 'risk' => 'High', 'tip' => 'Immediate action requests are often scams.'],
    ['word' => 'winner', 'risk' => 'High', 'tip' => 'If you didn\'t enter, you didn\'t win.'],
    ['word' => 'lottery', 'risk' => 'High', 'tip' => 'Lottery wins require a ticket purchase first.'],
    ['word' => 'wire transfer', 'risk' => 'High', 'tip' => 'Wire transfers are like cash; hard to trace and recover.'],
    ['word' => 'gift card', 'risk' => 'High', 'tip' => 'Government/Tech support never demands gift cards.'],
    ['word' => 'verify your account', 'risk' => 'High', 'tip' => 'Check the URL carefully; this is likely phishing.'],
    ['word' => 'suspended', 'risk' => 'High', 'tip' => 'Fear tactics are common in scams.'],
    ['word' => 'irs', 'risk' => 'High', 'tip' => 'The IRS sends mail, they do not email/text first.'],
    ['word' => 'social security', 'risk' => 'High', 'tip' => 'Never share your SSN.'],
    ['word' => 'inheritance', 'risk' => 'High', 'tip' => 'Unexpected inheritance is a classic scam.'],
    ['word' => 'shipping fee', 'risk' => 'High', 'tip' => 'Prizes shouldn\'t cost money to receive.'],
    ['word' => 'click here', 'risk' => 'High', 'tip' => 'Hover over links to see where they go.'],
    ['word' => 'limited time', 'risk' => 'Moderate', 'tip' => 'Urgency is a red flag.'],
    ['word' => 'offer expires', 'risk' => 'Moderate', 'tip' => 'Don\'t let a timer pressure you.'],
    ['word' => 'deal', 'risk' => 'Moderate', 'tip' => 'Check if the deal is real elsewhere.'],
    ['word' => 'discount', 'risk' => 'Moderate', 'tip' => 'Too good to be true usually is.'],
    ['word' => 'unknown sender', 'risk' => 'Moderate', 'tip' => 'Be wary of messages from strangers.'],
    ['word' => 'verify', 'risk' => 'Moderate', 'tip' => 'Why do they need verification now?'],
    ['word' => 'update', 'risk' => 'Moderate', 'tip' => 'Updates should happen in the app store, not via link.'],
    ['word' => 'login', 'risk' => 'Moderate', 'tip' => 'Ensure you are on the real website.'],
    ['word' => 'free', 'risk' => 'Moderate', 'tip' => 'Nothing is truly free.'],
    ['word' => 'prize', 'risk' => 'Moderate', 'tip' => 'Did you actually enter a contest?']
];

$risk_score = 0;
$matches = [];
$found_flags = []; // Legacy support for simple list if needed

foreach ($scam_indicators as $indicator) {
    if (stripos($text, $indicator['word']) !== false) {
        $score_add = ($indicator['risk'] === 'High') ? 5 : 2;
        $risk_score += $score_add;

        // Add to matches
        $matches[] = [
            'keyword' => $indicator['word'],
            'risk' => $indicator['risk'],
            'tip' => $indicator['tip']
        ];

        $found_flags[] = "{$indicator['risk']} risk: '{$indicator['word']}' - {$indicator['tip']}";
    }
}

// Check for URLs
if (preg_match('/https?:\/\/[^\s]+/', $text, $url_matches)) {
    $risk_score += 3;
    $matches[] = [
        'keyword' => $url_matches[0],
        'risk' => 'Moderate',
        'tip' => 'Verify this link is safe before clicking.'
    ];
    $found_flags[] = "Contains a link: Check destination.";
}

$risk_level = 'Safe';
if ($risk_score >= 5) {
    $risk_level = 'High';
} elseif ($risk_score >= 2) {
    $risk_level = 'Moderate';
}

// Save scan result
try {
    $stmt = $pdo->prepare("INSERT INTO scans (user_id, input_text, risk_level) VALUES (?, ?, ?)");
    $stmt->execute([$user_id, $text, $risk_level]);
} catch (PDOException $e) {
    // Log error but don't fail the response
}

jsonResponse([
    'risk' => $risk_level,
    'score' => $risk_score,
    'matches' => $matches,
    'flags' => $found_flags
]);
