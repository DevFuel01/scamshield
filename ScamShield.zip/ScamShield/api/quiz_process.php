<?php
require_once '../includes/db.php';
require_once '../includes/functions.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Fetch random questions
    try {
        $stmt = $pdo->query("SELECT id, question, option_a, option_b, option_c, option_d FROM quiz_questions ORDER BY RAND() LIMIT 5");
        $questions = $stmt->fetchAll();
        jsonResponse(['status' => 'success', 'data' => $questions]);
    } catch (PDOException $e) {
        jsonResponse(['status' => 'error', 'message' => 'Failed to fetch questions'], 500);
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Handle submission - Input expects JSON: { answers: { question_id: 'A', ... } }
    $input = json_decode(file_get_contents('php://input'), true);
    $answers = $input['answers'] ?? [];
    $user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : NULL;

    if (empty($answers)) {
        jsonResponse(['status' => 'error', 'message' => 'No answers provided'], 400);
    }

    $score = 0;
    $total = 0;
    $results_detail = [];

    // Fetch correct answers to compare
    $placeholders = str_repeat('?,', count($answers) - 1) . '?';
    $question_ids = array_keys($answers);

    if (empty($question_ids)) {
        jsonResponse(['status' => 'error', 'message' => 'Invalid data'], 400);
    }

    $sql = "SELECT id, correct_option FROM quiz_questions WHERE id IN ($placeholders)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($question_ids);
    $correct_answers_db = $stmt->fetchAll(PDO::FETCH_KEY_PAIR); // [id => correct_option]

    foreach ($answers as $q_id => $user_ans) {
        $total++;
        $is_correct = false;
        $correct_opt = $correct_answers_db[$q_id] ?? 'N/A';

        if (strtoupper($user_ans) === $correct_opt) {
            $score++;
            $is_correct = true;
        }
        $results_detail[$q_id] = [
            'correct' => $is_correct,
            'user_answer' => $user_ans,
            'correct_answer' => $correct_opt
        ];
    }

    if ($user_id) {
        // Save result
        $stmt = $pdo->prepare("INSERT INTO quiz_results (user_id, score, total_questions) VALUES (?, ?, ?)");
        $stmt->execute([$user_id, $score, $total]);

        // Update user total score/stats if we wanted to maintain a leaderboard, but for now simple history is fine
    }

    jsonResponse([
        'status' => 'success',
        'score' => $score,
        'total' => $total,
        'details' => $results_detail
    ]);
}
