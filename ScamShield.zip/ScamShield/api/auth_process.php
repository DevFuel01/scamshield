<?php
require_once '../includes/db.php';
require_once '../includes/functions.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'register') {
        $name = sanitize($_POST['name'] ?? '');
        $email = sanitize($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';

        if (empty($name) || empty($email) || empty($password)) {
            jsonResponse(['status' => 'error', 'message' => 'All fields are required'], 400);
        }

        // Check if email exists
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            jsonResponse(['status' => 'error', 'message' => 'Email already registered'], 400);
        }

        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?)");

        try {
            $stmt->execute([$name, $email, $hashed_password]);
            $_SESSION['user_id'] = $pdo->lastInsertId();
            $_SESSION['user_name'] = $name;
            jsonResponse(['status' => 'success', 'message' => 'Registration successful']);
        } catch (PDOException $e) {
            jsonResponse(['status' => 'error', 'message' => 'Registration failed'], 500);
        }
    } elseif ($action === 'login') {
        $email = sanitize($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';

        if (empty($email) || empty($password)) {
            jsonResponse(['status' => 'error', 'message' => 'Email and password required'], 400);
        }

        $stmt = $pdo->prepare("SELECT id, name, password FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['name'];
            jsonResponse(['status' => 'success', 'message' => 'Login successful']);
        } else {
            jsonResponse(['status' => 'error', 'message' => 'Invalid credentials'], 401);
        }
    } elseif ($action === 'logout') {
        session_destroy();
        jsonResponse(['status' => 'success', 'message' => 'Logged out']);
    } else {
        jsonResponse(['status' => 'error', 'message' => 'Invalid action'], 400);
    }
} else {
    jsonResponse(['status' => 'error', 'message' => 'Invalid request method'], 405);
}
