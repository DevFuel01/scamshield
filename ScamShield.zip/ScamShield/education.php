<?php include 'includes/header.php'; ?>

<h1 style="text-align: center; margin-bottom: 30px;"><i class="fas fa-book-open"></i> Holiday Scam Education Hub</h1>

<div style="background: linear-gradient(135deg, #165B33, #114a29); color: white; padding: 20px; border-radius: 10px; margin-bottom: 30px; box-shadow: 0 4px 15px rgba(0,0,0,0.2);">
    <h2 style="margin-top: 0; text-align: center;"><i class="fas fa-shield-alt"></i> Maximum Safety Checklist</h2>
    <div style="display: flex; flex-wrap: wrap; justify-content: space-around; text-align: center; gap: 20px; margin-top: 20px;">
        <div style="flex: 1; min-width: 200px;">
            <i class="fas fa-hand-holding-heart fa-2x" style="color: var(--christmas-gold); margin-bottom: 10px;"></i>
            <h3>Verify Charities</h3>
            <p style="font-size: 0.9rem;">Donate only via official websites.</p>
        </div>
        <div style="flex: 1; min-width: 200px;">
            <i class="fas fa-link fa-2x" style="color: var(--christmas-gold); margin-bottom: 10px;"></i>
            <h3>Check URLs</h3>
            <p style="font-size: 0.9rem;">Inspect links (hover before clicking).</p>
        </div>
        <div style="flex: 1; min-width: 200px;">
            <i class="fas fa-mouse-pointer fa-2x" style="color: var(--christmas-gold); margin-bottom: 10px;"></i>
            <h3>Avoid Unknown Links</h3>
            <p style="font-size: 0.9rem;">Don't click text links from strangers.</p>
        </div>
    </div>
</div>

<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px;">

    <div class="card">
        <h3><i class="fas fa-gift" style="color: var(--christmas-red);"></i> Reference: The "Free Gift" Scam</h3>
        <p>Scammers claim you've won a prize but need to pay "shipping fees". Legitimate contests never ask for money to claim a prize.</p>
        <p><strong>Red Flags:</strong> Requests for credit card info, urgency, sender email looks weird.</p>
    </div>

    <div class="card">
        <h3><i class="fas fa-shipping-fast" style="color: var(--christmas-gold);"></i> Reference: Fake Delivery Notifications</h3>
        <p>You get a text saying a package couldn't be delivered with a link to maintain it. This link steals your personal info.</p>
        <p><strong>Tip:</strong> Don't click the link. Go to the carrier's official site and type in the tracking number if you have one.</p>
    </div>

    <div class="card">
        <h3><i class="fas fa-heart" style="color: var(--christmas-red);"></i> Reference: Charity Fraud</h3>
        <p>Fake charities pop up during the holidays asking for donations via wire transfer or gift cards.</p>
        <p><strong>Tip:</strong> Donate to well-known organizations directly through their official websites.</p>
    </div>

    <div class="card">
        <h3><i class="fas fa-tags" style="color: var(--christmas-green);"></i> Reference: Too-Good-To-Be-True Deals</h3>
        <p>Ads on social media for popular toys or electronics at 90% off. These sites often take your money and send nothing.</p>
        <p><strong>Tip:</strong> Research the seller. If it looks too cheap, it's likely a scam.</p>
    </div>

    <div class="card">
        <h3><i class="fas fa-user-friends" style="color: var(--christmas-gold);"></i> Reference: Grandparent/Friend Scam</h3>
        <p>A designated "family member" calls saying they are in trouble and need money ASAP.</p>
        <p><strong>Tip:</strong> Hang up and call the person on their known phone number to verify.</p>
    </div>

    <div class="card">
        <h3><i class="fas fa-envelope-open-text" style="color: var(--christmas-red);"></i> Reference: "mismatched" Gift Exchange</h3>
        <p>Viral posts claim if you send one gift ($10), you'll receive 36 in return. It's a pyramid scheme.</p>
        <p><strong>Tip:</strong> These are illegal and you will likely lose money. Do not participate.</p>
    </div>

</div>

<div style="text-align: center; margin-top: 40px;">
    <h2>Ready to test your knowledge?</h2>
    <a href="quiz.php" class="btn">Take the Christmas Scam Quiz!</a>
</div>

<?php include 'includes/footer.php'; ?>