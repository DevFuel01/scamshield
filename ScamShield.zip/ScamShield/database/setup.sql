CREATE DATABASE IF NOT EXISTS scamshield;
USE scamshield;

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) DEFAULT NULL, -- Nullable for guest users if we decide to track them by session later, but mainly for auth
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS scans (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT DEFAULT NULL,
    input_text TEXT,
    risk_level ENUM('Safe', 'Moderate', 'High') NOT NULL,
    scan_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS quiz_questions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    question TEXT NOT NULL,
    option_a VARCHAR(255) NOT NULL,
    option_b VARCHAR(255) NOT NULL,
    option_c VARCHAR(255) NOT NULL,
    option_d VARCHAR(255) NOT NULL,
    correct_option CHAR(1) NOT NULL -- 'A', 'B', 'C', or 'D'
);

CREATE TABLE IF NOT EXISTS quiz_results (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    score INT NOT NULL,
    total_questions INT NOT NULL,
    attempt_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Seed Data for Quiz
INSERT INTO quiz_questions (question, option_a, option_b, option_c, option_d, correct_option) VALUES 
('You receive an email claiming you won a $500 Amazon gift card from "Santa". It asks for your credit card to pay for shipping. What do you do?', 'Pay the shipping immediately', 'Check the sender email address carefully', 'Forward it to all friends', 'Reply "Thank you"', 'B'),
('Which of these is a common sign of a holiday shopping scam?', 'Prices are slightly discounted', 'The website accepts credit cards', 'The website has no contact info and extremely low prices', 'It uses HTTPS', 'C'),
('A charity asks for donations via wire transfer or gift cards only. Is this safe?', 'Yes, it is fast', 'No, legitimate charities accept multiple payment methods', 'Yes, but only for Christmas', 'Maybe, if they have a nice logo', 'B'),
('You see a "Package Delivery Failed" text with a link. You are not expecting a package. What should you do?', 'Click the link to reschedule', 'Ignore and delete text', 'Call the police', 'Reply "Wrong number"', 'B'),
('A "friend" on social media sends a message asking for money for an emergency. It sounds urgent.', 'Send the money right away', 'Call the friend on a known number to verify', 'Ignore it', 'Ask for their bank details', 'B');
